# import utime
# import math
# from machine import I2C, Pin
# from compass.mpu9250 import MPU9250
# 
# class MPU:
#     def __init__(self, scl=22, sda=21):
#         i2c = I2C(scl=Pin(scl), sda=Pin(sda))
#         self.sensor = MPU9250(i2c)
# 
#         #self.sensor.accel_range = self.sensor.ACCEL_RANGE_16G
# #         self.sensor.gyro_range = self.sensor.GYRO_RANGE_2000DPS
# #         self.sensor.mag_mode = self.sensor.MAG_MODE_100HZ
# #         self.sensor.temp_source = self.sensor.TEMP_SOURCE_GYRO
# 
#         # Calibração
# #         self.sensor.mag_adjust()
# #         self.sensor.calibrate_accel()
# #         self.sensor.calibrate_gyro()
# #         self.sensor.calibrate_mag()
#         
#         print("MPU9250 inicializado com sucesso.")
# 
#     def get_accel(self):
#         return self.sensor.acceleration
#         
#     def get_gyro(self):
#         return self.sensor.gyro
# 
# 
# 
#     def get_head(self):
#         filtered_magx, filtered_magy, filtered_magz = 0, 0, 0
#         DECLINATION = -1 * 16.10
#         
#         def low_pass_filter(prev_value, new_value):
#             return 0.85 * prev_value + 0.15 * new_value
#         
#         magx_new, magy_new, magz_new= sensor.magnetic
#         
#         filtered_magx = low_pass_filter(filtered_magx, magx_new)
#         filtered_magy = low_pass_filter(filtered_magy, magy_new)
#         filtered_magz = low_pass_filter(filtered_magz, magz_new)
#         
#         heading_angle_in_degrees = math.atan2(filtered_magx, filtered_magy) * (180 / math.pi)
#         heading_angle_in_degrees_plus_declination = heading_angle_in_degrees + DECLINATION
#         
#         if heading_angle_in_degrees_plus_declination < 0:
#             heading_angle_in_degrees += 360
#             heading_angle_in_degrees_plus_declination += 360
# 
#         return heading_angle_in_degrees_plus_declination
#     
#     def get_temp(self):
#         return self.sensor.temperature
#     


  ####v2####
    
import utime
import math
from machine import SoftI2C, Pin
from compass.mpu9250 import MPU9250
import math
from collections import deque

class MPU:
    def __init__(self, scl=22, sda=21):
        i2c = SoftI2C(scl=Pin(scl), sda=Pin(sda))
        self.sensor = MPU9250(i2c)

        self.filtered_magx = 0
        self.filtered_magy = 0
        self.filtered_magz = 0

#     def __init__(self, scl, sda):
#         # Inicialização do sensor
#         #self.sensor = ...  # inicialização real do sensor
#         self.filtered_magx = 0
#         self.filtered_magy = 0
#         self.filtered_magz = 0
# 
#         # Buffer para filtro de mediana
#         self.heading_buffer = deque(maxlen=9)  # use tamanho ímpar (5,7,9)
        
        print("MPU9250 inicializado com sucesso.")

    def get_accel(self):
        return self.sensor.acceleration
        
    def get_gyro(self):
        return self.sensor.gyro

#     def get_head(self):
#         DECLINATION = -1 * 35.00 #-1 * 16.10
# 
#         magx_new, magy_new, magz_new = self.sensor.magnetic
#         
#         self.filtered_magx = 0.90 * self.filtered_magx + 0.10 * magx_new
#         self.filtered_magy = 0.90 * self.filtered_magy + 0.10 * magy_new
#         self.filtered_magz = 0.90 * self.filtered_magz + 0.10 * magz_new
#         
#         heading = math.atan2(self.filtered_magx, self.filtered_magy) * (180 / math.pi)
#         heading += DECLINATION
#         if heading < 0:
#             heading += 360
#         
#         angle = heading
#         
#         if (angle > 348.75) or (angle <= 11.25):
#             direction = "North"
#         elif angle > 11.25 and angle <= 33.75:
#             direction = "North-Northeast"
#         elif angle > 33.75 and angle <= 56.25:
#             direction = "Northeast"
#         elif angle > 56.25 and angle <= 78.75:
#             direction = "East-Northeast"
#         elif angle > 78.75 and angle <= 101.25:
#             direction = "East"
#         elif angle > 101.25 and angle <= 123.75:
#             direction = "East-Southeast"
#         elif angle > 123.75 and angle <= 146.25:
#             direction = "Southeast"
#         elif angle > 146.25 and angle <= 168.75:
#             direction = "South-Southeast"
#         elif angle > 168.75 and angle <= 191.25:
#             direction = "South"
#         elif angle > 191.25 and angle <= 213.75:
#             direction = "South-Southwest"
#         elif angle > 213.75 and angle <= 236.25:
#             direction = "Southwest"
#         elif angle > 236.25 and angle <= 258.75:
#             direction = "West-Southwest"
#         elif angle > 258.75 and angle <= 281.25:
#             direction = "West"
#         elif angle > 281.25 and angle <= 303.75:
#             direction = "West-Northwest"
#         elif angle > 303.75 and angle <= 326.25:
#             direction = "Northwest"
#         elif angle > 326.25 and angle <= 348.75:
#             direction = "North-Northwest"
#         
#         values = [
#             
#             direction,
#             heading
#             
#             ]
#         
#         #return "{}°, {}".format(round(values[1], 2), values[0])  ##heading % 360
#         return heading
    
#     def get_temp(self):
#     
#         return self.sensor.temperature
    
    def get_temp(self):
        temp = self.sensor.temperature
        return "{:.2f}°C".format(temp)



#class MPU:


    def get_head(self):
        # Declinação magnética em radianos
        DECLINATION = math.radians(35)#33.70)  # ajuste conforme necessário

        magx_new, magy_new, magz_new = self.sensor.magnetic

        # Filtro exponencial para suavizar ruído nos eixos magnéticos
        self.filtered_magx = 0.90 * self.filtered_magx + 0.10 * magx_new
        self.filtered_magy = 0.90 * self.filtered_magy + 0.10 * magy_new
        self.filtered_magz = 0.90 * self.filtered_magz + 0.10 * magz_new

        # Cálculo do heading em radianos
        heading = math.atan2(self.filtered_magx, self.filtered_magy)
        heading += DECLINATION

        # Normaliza para [0, 2*pi)
        if heading < 0:
            heading += 2 * math.pi
        elif heading >= 2 * math.pi:
            heading -= 2 * math.pi

        # Adiciona ao buffer para mediana
       # self.heading_buffer.append(heading)

        # Calcula mediana
        #sorted_buffer = sorted(self.heading_buffer)
        #median_heading = sorted_buffer[len(sorted_buffer) // 2]

        # Determina direção textual (opcional)
        angle_deg = 0#math.degrees(median_heading)
        if (angle_deg > 348.75) or (angle_deg <= 11.25):
            direction = "North"
        elif angle_deg <= 33.75:
            direction = "North-Northeast"
        elif angle_deg <= 56.25:
            direction = "Northeast"
        elif angle_deg <= 78.75:
            direction = "East-Northeast"
        elif angle_deg <= 101.25:
            direction = "East"
        elif angle_deg <= 123.75:
            direction = "East-Southeast"
        elif angle_deg <= 146.25:
            direction = "Southeast"
        elif angle_deg <= 168.75:
            direction = "South-Southeast"
        elif angle_deg <= 191.25:
            direction = "South"
        elif angle_deg <= 213.75:
            direction = "South-Southwest"
        elif angle_deg <= 236.25:
            direction = "Southwest"
        elif angle_deg <= 258.75:
            direction = "West-Southwest"
        elif angle_deg <= 281.25:
            direction = "West"
        elif angle_deg <= 303.75:
            direction = "West-Northwest"
        elif angle_deg <= 326.25:
            direction = "Northwest"
        else:
            direction = "North-Northwest"

        # Retorna heading em radianos (e direção opcional)
        return heading  # ou (median_heading, direction) se quiser direção também
