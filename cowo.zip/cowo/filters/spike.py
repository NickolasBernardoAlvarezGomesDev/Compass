

import utime
import math

class spike:
    def __init__(self, max_delta = 5):
        self.last_value = None
        self.max_delta = max_delta
        
    def filtro(self, new_value):
        if self.last_value in None:
            self.last_value = new_value
            return new_value
        delta = new_value - self.last_value
        if abs(delta) > self.max_delta:
            new_value = self.last_value + self.max_value * (1 if delta > 0 else -1)
            self.last_value = new_value
            return new_value